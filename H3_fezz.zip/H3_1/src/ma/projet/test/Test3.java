/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ma.projet.test;

import java.util.Calendar;
import java.util.Date;
import ma.projet.classes.Employe;
import ma.projet.classes.EmployeTache;
import ma.projet.classes.EmployeTachePK;
import ma.projet.classes.Projet;
import ma.projet.classes.Tache;
import ma.projet.services.EmployeService;
import ma.projet.services.EmployeTacheService;
import ma.projet.services.ProjetService;
import ma.projet.services.TacheService;

/**
 *
 * @author HP
 */
public class Test3 {
    public static void main(String[] args) {
        EmployeService es = new EmployeService();
        EmployeTacheService ets = new EmployeTacheService();
        ProjetService ps = new ProjetService();
        TacheService ts = new TacheService();

        // Create employees
        Employe e1 = new Employe("anwar", "Bliout", "0667805006");
        Employe e2 = new Employe("mohamed", "fezzazi", "064572219");
        es.create(e1);
        es.create(e2);

        // Create a project
        Calendar calendarDebut1 = Calendar.getInstance();
        calendarDebut1.set(2022, Calendar.OCTOBER, 5);
        Calendar calendarDebut2 = Calendar.getInstance();
        calendarDebut2.set(2022, Calendar.DECEMBER, 16);
        Projet p = new Projet("Finance", calendarDebut1.getTime(), calendarDebut2.getTime(), e2);

        // Print statements to check the state of the project
        System.out.println("Project before creation: " + p);

        ps.create(p);

        // Print statements to check the state of the project after creation
        System.out.println("Project after creation: " + p);

        // Create tasks
        Tache t = new Tache("Bilan", calendarDebut1.getTime(), calendarDebut2.getTime(), 20000, p);
        Tache t2 = new Tache("comptabilite", calendarDebut1.getTime(), calendarDebut2.getTime(), 10000, p);
        ts.create(t);
        ts.create(t2);

        // Attribution of tasks to "mohamed"
        Date dateAttribution = new Date();

        EmployeTachePK employeTachePK1 = new EmployeTachePK(e2.getId(), t.getId(), dateAttribution);
        EmployeTache employeTache1 = new EmployeTache(employeTachePK1);
        ets.create(employeTache1);

        EmployeTachePK employeTachePK2 = new EmployeTachePK(e2.getId(), t2.getId(), dateAttribution);
        EmployeTache employeTache2 = new EmployeTache(employeTachePK2);
        ets.create(employeTache2);

        System.out.println("Tasks assigned to 'mohamed'.");
        es.getTasksPerformedByEmployee(e2);
        es.getProjectsManagedByEmployee(e2);

        // Retrieve tasks for the project
        ps.getTachesByProjets(p);
    }
}


